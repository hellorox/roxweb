class DrawController < ApplicationController

layout "standard"

def index
end  

end
