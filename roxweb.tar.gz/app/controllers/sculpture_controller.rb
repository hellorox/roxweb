class SculptureController < ApplicationController

layout "standard"

  def index
  end

end
