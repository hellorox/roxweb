class InfoController < ApplicationController

layout "standard"

  def index
  end

end
