class HomeController < ApplicationController
  
layout "standard"

def index
end  

end
