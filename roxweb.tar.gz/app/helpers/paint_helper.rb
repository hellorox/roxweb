module PaintHelper
end
